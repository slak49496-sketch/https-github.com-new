import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.snkeditor.aivideostudio',
  appName: 'AI Video Studio',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
