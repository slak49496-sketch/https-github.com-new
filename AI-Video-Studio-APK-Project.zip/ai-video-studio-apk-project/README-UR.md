# AI Video Studio — Android APK project

یہ پروجیکٹ آپ کی اپلوڈ کردہ `AI Video Maker Studio.html` فائل کو Capacitor کے ذریعے Android APK میں پیک کرنے کے لیے تیار کیا گیا ہے۔

## مفت طریقہ: GitHub Actions سے APK بنائیں

1. ZIP فائل کو Extract کریں۔
2. GitHub پر ایک نیا repository بنائیں۔ اسے Public رکھ سکتے ہیں تاکہ مفت Actions limits کے اندر build آسان رہے؛ اگر Private رکھیں تو اپنے اکاؤنٹ کی Actions limits چیک کریں۔
3. اس فولڈر کے اندر موجود تمام فائلیں repository میں upload کریں، خاص طور پر `.github/workflows/build-apk.yml` بھی۔
4. GitHub repository میں **Actions** tab کھولیں۔
5. **Build Android APK** workflow منتخب کریں اور **Run workflow** دبائیں۔ اگر workflow نظر نہ آئے تو پہلے `main` branch پر فائلیں commit/push کریں۔
6. Build مکمل ہونے پر اسی workflow run کے نیچے **Artifacts** میں `AI-Video-Studio-debug-APK` ڈاؤن لوڈ کریں۔
7. ZIP artifact کھولیں، `app-debug.apk` فون میں منتقل کریں اور انسٹال کریں۔ Android میں ضرورت پڑنے پر صرف اپنے معتبر سورس کے لیے “Install unknown apps” کی اجازت دیں۔

## اہم حدود

- یہ HTML کو Android app میں پیک کرتا ہے؛ اس سے خود بخود تمام AI فیچرز فعال نہیں ہوتے۔
- موجودہ HTML میں script generator ایک سادہ built-in template writer ہے؛ یہ مکمل AI model نہیں ہے۔
- Narration preview فون/براؤزر کی دستیاب speech voices پر منحصر ہے۔
- موجودہ HTML میں `Render MP4` بٹن disabled ہے۔ فائل کے مطابق MP4 بنانے کے لیے FFmpeg والا renderer/server درکار ہے؛ یہ APK اکیلی MP4 ویڈیو render نہیں کرے گی۔
- Scene images/videos اور background music ابھی placeholders ہیں۔
- API keys کو HTML یا APK میں محفوظ نہ کریں۔ اگر بعد میں AI provider شامل کریں تو key server-side رکھیں۔

## App identity

- App name: AI Video Studio
- Android application ID: `com.snkeditor.aivideostudio`
- Build type: Debug APK (test/install کرنے کے لیے)
